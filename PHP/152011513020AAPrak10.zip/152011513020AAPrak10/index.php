

<!docfile html>
<head>

<script type = "text/javascript" src="matriks_vektor.js"> </script>

</head>

<body>
	
<h1>PHP connect to MySQL</h1>


<h1>javascript operasi matriks dan Vektor</h1>


<script>

	document.write("<br />");
	var jruang = 3;
	var jhari = 2;
	var jam = 3;
	var nGen = jruang*jhari*jam;
	var nPop = 5;
	document.write("jruang,jhari,jam ==> "+jruang+","+jhari+","+jam+"<br />");
	
	console.log(jruang);
	console.log(jhari);
	console.log(jam);
	console.log(nGen);
	console.log(nPop);
	console.log("jruang,jhari,jam ==> "+jruang+","+jhari+","+jam);
	


	var m2 = OperasiMatriks.generatePop(nPop,nGen);
	document.write("mat generatePop : <br />");	
	document.write(m2[0][0]+"<br />");

	console.log(m2);
	console.log("mat generatePop :");
	console.log(m2[0][0]);



	document.write("mat ubahPopKeBulat : <br />");
	var m3 = OperasiMatriks.ubahPopKeBulat(m2);
	document.write(m3[0][0]);

	console.log("mat ubahPopKeBulat :");
	console.log(m3);
	console.log(m3[0][0]);



	console.debug("Debug");
	console.info("Hello World");
	console.warn("Ini Peringatan");
	console.error("Ini Error");
	console.table(m3);


	
	
	
	
</script>


</body>


</html>